//
//  ConfirmarController.swift
//  PizzaAW
//
//  Created by Romina Pozzuto on 13/01/2020.
//  Copyright © 2020 Romina Pozzuto. All rights reserved.
//

import WatchKit
import Foundation


class ConfirmarController: WKInterfaceController {
    var masa: String = ""
    var tamano: String = ""
    var queso:String = ""
    var ingredientes:String = ""
    
    @IBOutlet weak var labelTamaño: WKInterfaceLabel!
    @IBOutlet weak var labelMasa: WKInterfaceLabel!
    
    @IBOutlet weak var labelQueso: WKInterfaceLabel!
    
    @IBOutlet weak var labelIngredientes: WKInterfaceLabel!
    
    @IBOutlet weak var confirmarbutton: WKInterfaceButton!
    
    
    @IBAction func buttonConfirmar() {
        pushController(withName: "PedidoOk", context: "")
        
    }
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        let c=context as! Valor
        self.tamano = c.tamano
        self.masa = c.masa
        self.queso = c.queso
        self.ingredientes = c.ingredientes
        
        self.labelTamaño.setText("Tamaño: " + tamano)
        self.labelMasa.setText("Masa: " + masa)
        self.labelQueso.setText("Queso: " + queso)
        self.labelIngredientes.setText("Ingredientes: " + ingredientes)
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}

