//
//  PedidoOk.swift
//  PizzaAW WatchKit Extension
//
//  Created by Romina Pozzuto on 13/01/2020.
//  Copyright © 2020 Romina Pozzuto. All rights reserved.
//

import WatchKit
import Foundation

class PedidoOk: WKInterfaceController {
    
    @IBOutlet weak var labelOk: WKInterfaceLabel!
    
    @IBOutlet weak var buttonSalir: WKInterfaceButton!
    
    
    @IBAction func salir() {
    pushController(withName: "InterfaceController", context: "")

    }
    
    override func awake(withContext context: Any?) {
          super.awake(withContext: context)
        self.labelOk.setText("¡Tu pedido está en camino!")
      }
    
    
}
