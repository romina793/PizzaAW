//
//  Valor.swift
//  PizzaAW
//
//  Created by Romina Pozzuto on 13/01/2020.
//  Copyright © 2020 Romina Pozzuto. All rights reserved.
//

import WatchKit

class Valor: NSObject {
    var tamano:String = ""
    var masa:String = ""
    var queso:String = ""
    var ingredientes:String = ""
    
    init (t:String, m:String, q:String, i:String){
        tamano = t
        masa = m
        queso = q
        ingredientes = i
    }

}
