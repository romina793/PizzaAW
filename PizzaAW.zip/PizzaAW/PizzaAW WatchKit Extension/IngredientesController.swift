//
//  IngredientesController.swift
//  PizzaAW
//
//  Created by Romina Pozzuto on 13/01/2020.
//  Copyright © 2020 Romina Pozzuto. All rights reserved.
//

import WatchKit
import Foundation


class IngredientesController: WKInterfaceController {
    var masaSeleccionada: String = ""
    var tamanoSeleccionado: String = ""
    var quesoSeleccionado:String = ""
    var ingredientesSeleccionado:String = ""
    
    var jamon = false
    var pepperoni = false
    var pavo = false
    var salchicha = false
    var aceituna = false
    var cebolla = false
    var pimiento = false
    var piña = false
    var anchoa = false
    
    
    @IBAction func isSelectionPavo(_ value: Bool) {
        if value == true {
            self.pavo = true
        }
        
    }
    
    @IBAction func isSelectionPepperoni(_ value: Bool) {
        if value == true {
            self.pepperoni = true
        }
        
    }
    
    @IBAction func isSelectionSalchicha(_ value: Bool) {
        if value == true {
            self.salchicha = true
        }
        
    }
    
    @IBAction func isSelectionJamon(_ value: Bool) {
        if value == true {
            self.jamon = true
        }
        
    }
    
    @IBAction func isSelectionAceituna(_ value: Bool) {
        if value == true {
            self.aceituna = true
        }
    }
    
    @IBAction func isSelectionCebolla(_ value: Bool) {
        if value == true {
            self.cebolla = true
        }
    }
    
    @IBAction func isSelectionPimiento(_ value: Bool) {
        if value == true {
            self.pimiento = true
        }
    }
    
    @IBAction func isSelectionPiña(_ value: Bool) {
        if value == true {
            self.piña = true
        }
    }
    
    @IBAction func isSelectionAnchoa(_ value: Bool) {
        if value == true {
            self.anchoa = true
        }
    }
    
    
    func verIngredientes ()->String{
        var ingrediente = ""
        if self.jamon == true {
            ingrediente = ingrediente + " Jamón,"
        }
        if self.pepperoni == true {
            ingrediente = ingrediente + " Pepperoni,"
        }
        if self.pavo == true {
            ingrediente = ingrediente + " Pavo,"
        }
        if self.salchicha == true {
            ingrediente = ingrediente + " Salchicha,"
        }
        if self.aceituna == true {
            ingrediente = ingrediente + " Aceituna,"
        }
        if self.cebolla == true {
            ingrediente = ingrediente + " Cebolla,"
        }
        if self.pimiento == true {
            ingrediente = ingrediente + " Pimiento,"
        }
        if self.piña == true {
            ingrediente = ingrediente + " Piña,"
        }
        if self.anchoa == true {
            ingrediente = ingrediente + " Anchoa,"
        }
        return ingrediente
    }
    
    
    
    @IBAction func nextButton() {
        let ingredientesSeleccionados = verIngredientes()
         let valorContext = Valor(t:tamanoSeleccionado, m:masaSeleccionada, q:quesoSeleccionado, i:ingredientesSeleccionados)
         pushController(withName: "ConfirmarController", context: valorContext)
        
    }

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        let c=context as! Valor
        self.tamanoSeleccionado = c.tamano
        self.masaSeleccionada = c.masa
        self.quesoSeleccionado = c.queso
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
