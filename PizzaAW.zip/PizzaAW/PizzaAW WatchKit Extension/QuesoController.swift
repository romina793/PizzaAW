//
//  QuesoController.swift
//  PizzaAW
//
//  Created by Romina Pozzuto on 13/01/2020.
//  Copyright © 2020 Romina Pozzuto. All rights reserved.
//

import WatchKit
import Foundation


class QuesoController: WKInterfaceController {
    
    var masa: String = ""
    var tamano: String = ""
    var queso:String = "Sin queso"
    
    @IBOutlet weak var labelQuesoPizza: WKInterfaceLabel!
    @IBOutlet weak var sliderQuesoPizza: WKInterfaceSlider!
    

    
    @IBAction func sliderActionQueso(_ value: Float) {
        
        if value == 0{
            self.labelQuesoPizza.setText("Sin queso")
            self.queso = "Sin queso"
         }
         if value == 1{
            self.labelQuesoPizza.setText("Mouzzarella")
            self.queso = "Mouzzarella"
         }
         if value == 2{
            self.labelQuesoPizza.setText("Cheddar")
            self.queso = "Cheddar"
         }
         if value == 3{
            self.labelQuesoPizza.setText("Parmesano")
            self.queso = "Parmesano"
         }
    }

    
    
    @IBAction func nextButton() {
        let valorContext = Valor(t:tamano, m: masa, q: queso, i:"")
        pushController(withName: "IngredientesController", context: valorContext)
    }
 
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        let c=context as! Valor
        self.tamano = c.tamano
        self.masa = c.masa
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
