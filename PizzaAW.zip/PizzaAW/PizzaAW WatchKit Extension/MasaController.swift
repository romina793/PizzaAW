//
//  MasaController.swift
//  PizzaAW
//
//  Created by Romina Pozzuto on 13/01/2020.
//  Copyright © 2020 Romina Pozzuto. All rights reserved.
//

import WatchKit
import Foundation


class MasaController: WKInterfaceController {

    
    @IBOutlet weak var labelMasaPizza: WKInterfaceLabel!
    @IBOutlet weak var sliderMasaPizza: WKInterfaceSlider!
    
    
    var masa: String = "Delgada"
    var tamano: String = ""
    

    @IBAction func sliderActionMasa(_ value: Float) {
        
        if value == 0{
            self.labelMasaPizza.setText("Delgada")
            self.masa = "Delgada"
        }
        if value == 1{
            self.labelMasaPizza.setText("Crujiente")
            self.masa = "Crujiente"
        }
        if value == 2{
            self.labelMasaPizza.setText("Gruesa")
            self.masa = "Gruesa"
        }
    }
    
    
    @IBAction func buttonNext() {
        let valorContext = Valor(t: tamano, m: masa, q:"", i:"")
          pushController(withName: "QuesoController", context: valorContext)
    }

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        let c=context as! Valor
        self.tamano = c.tamano
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
