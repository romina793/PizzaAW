//
//  InterfaceController.swift
//  PizzaAW WatchKit Extension
//
//  Created by Romina Pozzuto on 13/01/2020.
//  Copyright © 2020 Romina Pozzuto. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    
    
    @IBOutlet weak var labelTamañoPizza: WKInterfaceLabel!
    
    @IBOutlet weak var sliderTamañoPizza: WKInterfaceSlider!
    
    
    var tamaño : String = "Chica"
    
    @IBAction func sliderTamañoAction(_ value: Float) {
        labelTamañoPizza.setText(String(value))
        if value == 0{
            self.labelTamañoPizza.setText("Chica")
            self.tamaño = "Chica"
        }
        if value == 1{
            self.labelTamañoPizza.setText("Mediana")
            self.tamaño = "Mediana"
        }
        if value == 2{
            self.labelTamañoPizza.setText("Grande")
            self.tamaño = "Grande"
        }
        
    }
    
    @IBAction func buttonNext() {
        let valorContext = Valor(t: tamaño, m:"", q:"", i:"")
        pushController(withName: "MasaController", context: valorContext)
    }
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
